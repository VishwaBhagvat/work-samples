package com.example.vishwa.homework2app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;

import java.util.TimerTask;

public class MyService extends Service implements SensorEventListener
{
    private static final String TAG = "BOOMBOOMTESTGPS";
    private LocationManager mLocationManager = null;
    private static final int LOCATION_INTERVAL = 1000;
    private static final float LOCATION_DISTANCE = 10f;
    private SensorManager mSensorManager;
    private Sensor mStepCounterSensor;
    private Sensor mStepDetectorSensor;
    private RecordWorkout r1;
    private long startTime = 0L;
    long timeInMilliseconds =0L;         // r.TimeInMilliseconds.get(0);
    int secs=0;            //=r.seconds.get(0);
    int mins=0;    //r.minutes.get(0);
    int milliseconds=0;   //r.Milliseconds.get(0);

    long timeSwapBuff =0L;   // r.TimeSwapBuff.get(0);

    long updatedTime =0L;  // r.Up
    Handler handler=new Handler();



    private class LocationListener implements android.location.LocationListener, SensorEventListener
    {
        private RecordWorkout r;
        Location mLastLocation;


        @Override
        public void onSensorChanged(SensorEvent event) {

            Sensor sensor = event.sensor;
            float[] values = event.values;
            double value = -1;
            double calories=0;

            if (values.length > 0) {
                value =(double) values[0]/2112;
                calories=(double) values[0]/20;
                r.averageweeklydistanceArray.set(0, value);
                r.alltimedistanceArray.set(0, value);
                r.averageweeklycaloriesburntArray.set(0, calories);
                r.alltimecaloriesburntArray.set(0, calories);

            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy)
        {

        }



        public LocationListener(String provider)
        {
            Log.e(TAG, "LocationListener " + provider);
            mLastLocation = new Location(provider);
        }

        @Override
        public void onLocationChanged(Location location)
        {
            Log.e(TAG, "onLocationChanged: " + location);
            LatLng here = new LatLng(location.getLatitude(), location.getLongitude());
            // mMap.addMarker(new MarkerOptions().position(here).title("Marker"));
            // p.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(here, 17));
            r.points.add(here);
            // p.redrawLine();
        }

        @Override
        public void onProviderDisabled(String provider)
        {
            Log.e(TAG, "onProviderDisabled: " + provider);
        }

        @Override
        public void onProviderEnabled(String provider)
        {
            Log.e(TAG, "onProviderEnabled: " + provider);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras)
        {
            Log.e(TAG, "onStatusChanged: " + provider);
        }
    }



    LocationListener[] mLocationListeners = new LocationListener[] {
            new LocationListener(LocationManager.GPS_PROVIDER),
            new LocationListener(LocationManager.NETWORK_PROVIDER)
    };

    @Override
    public IBinder onBind(Intent arg0)
    {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Log.e(TAG, "onStartCommand");
        super.onStartCommand(intent, flags, startId);


        return START_STICKY;
    }



    @Override
    public void onCreate()
    {
        Log.e(TAG, "onCreate");

        mSensorManager=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mStepCounterSensor=mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        mStepDetectorSensor=mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        startTime = SystemClock.uptimeMillis();


        handler.postDelayed(updateTimer, 0);
        initializeLocationManager();
        mSensorManager.registerListener(this, mStepCounterSensor, SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(this, mStepDetectorSensor, SensorManager.SENSOR_DELAY_FASTEST);
        try {
            mLocationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER, LOCATION_INTERVAL, LOCATION_DISTANCE,
                    mLocationListeners[1]);
        } catch (java.lang.SecurityException ex) {
            Log.i(TAG, "fail to request location update, ignore", ex);
        } catch (IllegalArgumentException ex) {
            Log.d(TAG, "network provider does not exist, " + ex.getMessage());
        }
        try {
            mLocationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, LOCATION_INTERVAL, LOCATION_DISTANCE,
                    mLocationListeners[0]);
        } catch (java.lang.SecurityException ex) {
            Log.i(TAG, "fail to request location update, ignore", ex);
        } catch (IllegalArgumentException ex) {
            Log.d(TAG, "gps provider does not exist " + ex.getMessage());
        }

    }

    @Override
    public void onDestroy()
    {
        Log.e(TAG, "onDestroy");
        super.onDestroy();


        if (mLocationManager != null) {
            for (int i = 0; i < mLocationListeners.length; i++) {
                try {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        mLocationManager.removeUpdates(mLocationListeners[i]);
                    }
                } catch (Exception ex) {
                    Log.i(TAG, "fail to remove location listners, ignore", ex);
                }
            }
        }
    }

    private void initializeLocationManager() {
        Log.e(TAG, "initializeLocationManager");
        if (mLocationManager == null) {
            mLocationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        Sensor sensor = event.sensor;
        float[] values = event.values;
        double value = -1;
        double calories=0;

        if (values.length > 0) {
            value =(double) values[0]/2112;
            calories=(double) values[0]/20;
            r1.averageweeklydistanceArray.set(0, value);
            r1.alltimedistanceArray.set(0, value);
            r1.averageweeklycaloriesburntArray.set(0, calories);
            r1.alltimecaloriesburntArray.set(0, calories);

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }

    Runnable updateTimer = new Runnable() {

        public void run() {

            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;

            updatedTime = timeSwapBuff + timeInMilliseconds;

            secs = (int) (updatedTime / 1000);

            mins = secs / 60;

            secs = secs % 60;

            milliseconds = (int) (updatedTime % 1000);


            r1.averageweeklyminuteArray.set(0, mins);
            r1.alltimeminuteArray.set(0, mins);
            r1.averageweeklysecondArray.set(0, secs);
            r1.alltimesecondArray.set(0, secs);
            r1.millisecondsArray.set(0, milliseconds);

            handler.postDelayed(this, 0);

        }

    };





}
