package com.example.vishwa.homework2app;


import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

import static com.example.vishwa.homework2app.R.id.alltimeminutenumber;
import static com.example.vishwa.homework2app.R.id.gender;
import static com.example.vishwa.homework2app.portraitFragment.username;

public class userProfile extends AppCompatActivity {


    private RecordWorkout r2;
    TextView averageweeklydistance;
    TextView alltimedistance;
    TextView averageweeklycaloriesburnt;
    TextView alltimecaloriesburnt;
    TextView averageweeklyhour;
    TextView alltimehour;
    TextView averageweeklyminute;
    TextView alltimeminute;
     TextView averageweeklyseconds;
    TextView alltimeseconds;
    TextView averageweeklyworkoutnumber;
    TextView alltimeworkoutnumber;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        averageweeklydistance= (TextView) findViewById(R.id.distanceNumber);
        alltimedistance= (TextView) findViewById(R.id.distanceNumber);
        averageweeklycaloriesburnt= (TextView) findViewById(R.id.CaloriesBurntNumber);
        averageweeklyhour= (TextView) findViewById(R.id.hourNumber);
        averageweeklyminute= (TextView) findViewById(R.id.minuteNumber);
        averageweeklyseconds= (TextView) findViewById(R.id.secondNumber);
        alltimehour= (TextView) findViewById(R.id.alltimehourNumber);
        alltimeminute= (TextView) findViewById(R.id.alltimeminutenumber);
        alltimeseconds= (TextView) findViewById(R.id.alltimesecondNumber);
        averageweeklyworkoutnumber= (TextView) findViewById(R.id.WorkoutNumber);
        alltimeworkoutnumber= (TextView) findViewById(R.id.AlltimeWorkoutNumber);

        averageweeklycaloriesburnt= (TextView) findViewById(R.id.CaloriesBurntNumber);
        alltimecaloriesburnt= (TextView) findViewById(R.id.CaloriesBurntNumber);
        final EditText Username= (EditText) findViewById(R.id.userName);
        final EditText Gender = (EditText) findViewById(R.id.gender);
        final EditText Weight=(EditText) findViewById(R.id.userWeight);
        Button submit=(Button) findViewById(R.id.save);

        Username.setText(r2.username.get(0).toString());
        Gender.setText(r2.gender.get(0).toString());
        Weight.setText(r2.weight.get(0).toString());
        averageweeklydistance.setText(r2.averageweeklydistanceArray.get(0).toString());
        alltimedistance.setText(r2.alltimedistanceArray.get(0).toString());
        averageweeklycaloriesburnt.setText(r2.averageweeklycaloriesburntArray.get(0).toString());
        alltimecaloriesburnt.setText(r2.alltimecaloriesburntArray.get(0).toString());
        averageweeklyworkoutnumber.setText(r2.averageweeklyworkoutnumberArray.get(0).toString());
        alltimeworkoutnumber.setText(r2.alltimeworkoutnumberArray.get(0).toString());


        averageweeklyhour.setText(r2.averageweeklyhourArray.get(0).toString());
        averageweeklyminute.setText(r2.averageweeklyminuteArray.get(0).toString());
        averageweeklyseconds.setText(r2.millisecondsArray.get(0).toString());
        alltimeseconds.setText(r2.alltimesecondArray.get(0).toString());
        alltimeminute.setText(r2.alltimeminuteArray.get(0).toString());
        alltimeseconds.setText(r2.millisecondsArray.get(0).toString());

        //String URL="content://com.example.vishwa.homework2app.MyContentProvider";
        // Uri users=Uri.parse(URL);
        //Cursor c=managedQuery(users, null, null, null, "id");

      /*  if(c.moveToFirst()) {
            do{

                Toast.makeText(this, c.getString(c.getColumnIndex(MyContentProvider.name)), Toast.LENGTH_SHORT).show();





            }while (c.moveToNext());
          //  if(c.getString(c.getColumnIndex(MyContentProvider.name))!="") {
               //
          //  }
        }

*/




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Toast.makeText(getBaseContext(), "New Record inserted", Toast.LENGTH_LONG).show(
                //  String URL="content://com.example.vishwa.homework2app.MyContentProvider";
                //  Uri id=Uri.parse(URL);
                //  Cursor c=managedQuery(id, null, null, null, "id");
                // c.getString(c.getColumnIndex(MyContentProvider.name));





                r2.username.set(0, Username.getText().toString());
                r2.gender.set(0, Gender.getText().toString());
                r2.weight.set(0, Weight.getText().toString());
                //   weight.set(0, values.getAsString(MyContentProvider.WEIGHT));

                Context context=getApplicationContext();
                CharSequence text = "information saved";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();



            }
        });

    }

}

