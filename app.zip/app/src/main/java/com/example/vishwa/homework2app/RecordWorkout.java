package com.example.vishwa.homework2app;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.location.Criteria;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Arrays;

import com.example.vishwa.homework2app.landscapeFragment;
import com.example.vishwa.homework2app.portraitFragment;
import com.google.android.gms.maps.model.LatLng;

import static com.example.vishwa.homework2app.R.id.workoutButton;
import static java.sql.Types.INTEGER;


public class RecordWorkout extends Activity {


    public static int i;
    public static int j;
    public static ArrayList<String> workoutButtonText = new ArrayList<String>(Arrays.asList("start workout"));
    public static ArrayList<LatLng> points = new ArrayList<LatLng>();
    public static double steps=0;

    public static int averageweeklyhour=0;
    public static int averageweeklyminute=0;
    public static int averageweeklyworkoutnumber=0;
    public static double averageweeklycaloriesburnt=0;
    public static int averageweeklysecond=0;
    public static int alltimehour=0;
    public static int alltimeminute=0;
    public static int milliseconds=0;
    public static int alltimeworkoutnumber=0;
    public static double alltimecaloriesburnt=0;
    public static int alltimesecond=0;
    public static ArrayList<Double> averageweeklydistanceArray = new ArrayList<Double>(Arrays.asList(steps));
    public static ArrayList<Double> alltimedistanceArray = new ArrayList<Double>(Arrays.asList(steps));

    static ArrayList<String> username=new ArrayList<String>(Arrays.asList(""));
    static ArrayList<String> gender=new ArrayList<String>(Arrays.asList(""));
    static ArrayList<String> weight=new ArrayList<String>(Arrays.asList(""));
    public static ArrayList<Integer> millisecondsArray = new ArrayList<Integer>(Arrays.asList(milliseconds));
    public static ArrayList<Integer> averageweeklyhourArray = new ArrayList<Integer>(Arrays.asList(averageweeklyhour));
    static ArrayList<Integer> averageweeklyminuteArray=new ArrayList<Integer>(Arrays.asList(averageweeklyminute));
    static ArrayList<Integer> averageweeklysecondArray=new ArrayList<Integer>(Arrays.asList(averageweeklysecond));
    static ArrayList<Integer> averageweeklyworkoutnumberArray=new ArrayList<Integer>(Arrays.asList(averageweeklyworkoutnumber));
    static ArrayList<Double> averageweeklycaloriesburntArray=new ArrayList<Double>(Arrays.asList(averageweeklycaloriesburnt));
    static ArrayList<Integer> alltimehourArray=new ArrayList<Integer>(Arrays.asList(alltimehour));
     static ArrayList<Integer> alltimeminuteArray=new ArrayList<Integer>(Arrays.asList(alltimeminute));
    static ArrayList<Integer> alltimesecondArray=new ArrayList<Integer>(Arrays.asList(alltimesecond));
    static ArrayList<Integer> alltimeworkoutnumberArray=new ArrayList<Integer>(Arrays.asList(alltimeworkoutnumber));
    static ArrayList<Double> alltimecaloriesburntArray=new ArrayList<Double>(Arrays.asList(alltimecaloriesburnt));

    //Handler handler=new Handler();
  /*  public static ArrayList<Long> startTime = new ArrayList<Long>(Arrays.asList(0L));
    public static ArrayList<Long> TimeInMilliseconds = new ArrayList<Long>(Arrays.asList(0L));
    public static ArrayList<Integer> seconds = new ArrayList<Integer>(Arrays.asList(0));
    public static ArrayList<Integer> minutes = new ArrayList<Integer>(Arrays.asList(0));
    public static ArrayList<Integer> Milliseconds = new ArrayList<Integer>(Arrays.asList(0));
    public static ArrayList<Long> TimeSwapBuff = new ArrayList<Long>(Arrays.asList(0L));
    public static ArrayList<Long> UpdatedTime= new ArrayList<Long>(Arrays.asList(0L));
    */
    //  Handler handler = new Handler();



    // public static Handler customHandler = new Handler();
    //LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    // String locationProvider=locationManager.getBestProvider(new Criteria(), false);


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        // no more this
        setContentView(R.layout.activity_record_workout);



        Configuration config = getResources().getConfiguration();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            landscapeFragment landscapeFragment = new landscapeFragment();
            fragmentTransaction.replace(android.R.id.content, landscapeFragment);
        } else {
            portraitFragment portraitFragment = new portraitFragment();
            fragmentTransaction.replace(android.R.id.content, portraitFragment);


        }
        fragmentTransaction.commit();


    }
}
/*
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate()
    {
      super.onCreate();

         {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(locationProvider, 400, 1, this);
            }
    }
}

*/




