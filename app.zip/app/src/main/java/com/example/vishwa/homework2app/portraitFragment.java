package com.example.vishwa.homework2app;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.admin.SystemUpdatePolicy;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.SystemClock;



//import com.example.vishwa.homework2app.R;
import com.example.vishwa.homework2app.Manifest;
import com.example.vishwa.homework2app.R;
import com.example.vishwa.homework2app.RecordWorkout;
import com.example.vishwa.homework2app.userProfile;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;


import static com.example.vishwa.homework2app.R.id.activity_record_workout;
import static com.example.vishwa.homework2app.R.id.map;
import static com.example.vishwa.homework2app.R.id.workoutButton;
//import static com.example.vishwa.homework2app.RecordWorkout.i;
//import static com.example.vishwa.homework2app.RecordWorkout.j;


/**
 * A simple {@link Fragment} subclass.
 */
public class portraitFragment extends android.app.Fragment implements OnMapReadyCallback, SensorEventListener, android.location.LocationListener {
    public GoogleMap  mMap;
    private RecordWorkout r;
    private SensorManager mSensorManager;
    private Sensor mStepCounterSensor;
    private Sensor mStepDetectorSensor;
  //  private MyService s;


    public static ArrayList<String> username = new ArrayList<String>(Arrays.asList(""));
    public ArrayList<String> gender = new ArrayList<String>(Arrays.asList(""));
    public ArrayList<String> weight = new ArrayList<String>(Arrays.asList(""));
    public static int k = 0;
    public static int m = 0;
    //public ArrayList<LatLng> points;
    Polyline line;
    String locationProvider;
    LocationManager locationManager;
    Button workoutButton;
     TextView distance;
    int workoutNum;



    private long startTime = 0L;
    long timeInMilliseconds =0L;         // r.TimeInMilliseconds.get(0);
    int secs=0;            //=r.seconds.get(0);
    int mins=0;    //r.minutes.get(0);
    int milliseconds=0;   //r.Milliseconds.get(0);

    long timeSwapBuff =0L;   // r.TimeSwapBuff.get(0);

    long updatedTime =0L;  // r.UpdatedTime.get(0);
    public TextView timerValue;
    public TextView Distance;
    Handler handler=new Handler();







    public portraitFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View view = inflater.inflate(R.layout.fragment_portrait, container, false);



          mSensorManager=(SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        mStepCounterSensor=mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        mStepDetectorSensor=mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        workoutButton = (Button) view.findViewById(R.id.workoutButton);
        timerValue=(TextView) view.findViewById(R.id.timervalue);
        final ImageButton userProfileButton = (ImageButton) view.findViewById(R.id.userprofileButton);
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
          distance= (TextView) view.findViewById(R.id.distanceNumber);
        final TextView hournumber = (TextView) view.findViewById(R.id.hourNumber);
        final TextView minutenumber=(TextView) view.findViewById(R.id.minuteNumber);
        final TextView secondnumber=(TextView) view.findViewById(R.id.secondNumber);
        final TextView workoutnumber = (TextView) view.findViewById(R.id.WorkoutNumber);
        final TextView caloriesburntnumber=(TextView) view.findViewById(R.id.CaloriesBurntNumber);
        final TextView distancealltimenumber=(TextView) view.findViewById(R.id.DistanceAllTimeNumber);
        final TextView alltimehournumber = (TextView) view.findViewById(R.id.alltimehourNumber);
        final TextView alltimeminutenumber=(TextView) view.findViewById(R.id.alltimeminutenumber);
        final TextView alltimesecondnumber=(TextView) view.findViewById(R.id.alltimesecondNumber);
        final TextView alltimeworkoutnumber=(TextView) view.findViewById(R.id.AlltimeWorkoutNumber);
        final TextView alltimeburntcalories=(TextView) view.findViewById(R.id.alltimesecondNumber);
        locationProvider=locationManager.getBestProvider(new Criteria(), false);


        // points = new ArrayList<LatLng>();


        workoutButton.setText(r.workoutButtonText.get(0).toString());
      //  Distance.setText(r.distance.get(0).toString());

        k = 1;

        if(r.workoutButtonText.get(0).toString().equalsIgnoreCase("stop workout"))
        {
            startTime = SystemClock.uptimeMillis();


            handler.postDelayed(updateTimer, 0);
            timerValue.setText(r.averageweeklyminuteArray.get(0) +":"+r.averageweeklysecondArray.get(0)+":"+r.millisecondsArray.get(0));

        }
        else
        {
            startTime=0L;
            timeInMilliseconds=0L;
            timeSwapBuff=0L;
            updatedTime=0L;
            secs=0;
            mins=0;
            milliseconds=0;

            timerValue.setText("00:00:00");

        }



        userProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Intent intent = new Intent(portraitFragment.this, userProfile.class);
                // startActivity(intent);
                startActivity(new Intent(getActivity(), userProfile.class));
            }
        });

        workoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (workoutButton.getText().toString().equalsIgnoreCase("start workout")) {

                    //  startActivity(new Intent(getActivity(), MapsActivity.class));
                    //   Intent intent = new Intent(portraitFragment.this, MapsActivity.class);
                    // startActivity(intent);


                    startActivity(new Intent(getActivity(), RecordWorkout.class));
                    r.j = 1;
                    r.workoutButtonText.set(0, "stop workout");
                    getActivity().startService(new Intent(getActivity(), MyService.class));

                    // startTime = SystemClock.uptimeMillis();


                    //    r.handler.postDelayed(updateTimer, 0);




                    // getActivity().startService(new Intent(getActivity(), MyService.class));

                    // startTime = SystemClock.uptimeMillis();


                    // r.customHandler.postDelayed(updateTimerThread, 0);


                    // workoutButton.setText("stop workout");

                    //Intent intent = new Inte
//   nt(MainActivity.this, Banner.class);
                    //  startActivity(intent);
                } else {


                    r.points=new ArrayList<LatLng>();


                    for(int i=0; i<r.points.size(); i++)
                    {
                        r.points.remove(i);
                    }
                    r.j = 0;

                    getActivity().stopService(new Intent(getActivity(), MyService.class));
                    startActivity(new Intent(getActivity(), RecordWorkout.class));
                    r.workoutButtonText.set(0, "start workout");
                    handler.removeCallbacks(updateTimer);
                    ContentValues values=new ContentValues();

                    values.put(MyContentProvider.NAME, r.username.get(0).toString());
                    values.put(MyContentProvider.GENDER, r.gender.get(0).toString());
                    values.put(MyContentProvider.WEIGHT, r.weight.get(0).toString());

                   values.put(MyContentProvider.averageweeklydistance, r.averageweeklydistanceArray.get(0).toString());

                    values.put(MyContentProvider.averageweeklytimehour, r.averageweeklyhourArray.get(0).toString());

                    values.put(MyContentProvider.averageweeklytimeminutes, r.averageweeklyminuteArray.get(0).toString());
                    values.put(MyContentProvider.averageweeklytimeseconds, r.averageweeklysecondArray.get(0).toString());
                    values.put(MyContentProvider.averageweeklyworkoutnumber, r.averageweeklyworkoutnumberArray.get(0).toString());
                    values.put(MyContentProvider.averageweeklycaloriesburnt, r.averageweeklycaloriesburntArray.get(0).toString());

                    values.put(MyContentProvider.alltimedistance, r.alltimedistanceArray.get(0).toString());
                    values.put(MyContentProvider.alltimehour, r.alltimehourArray.get(0).toString());
                    values.put(MyContentProvider.alltimeminutes, r.alltimeminuteArray.get(0).toString());
                    values.put(MyContentProvider.alltimeseconds, r.alltimesecondArray.get(0).toString());
                    values.put(MyContentProvider.alltimeworkoutnumber, r.alltimeworkoutnumberArray.get(0).toString());
                    values.put(MyContentProvider.alltimecaloriesburnt, r.alltimecaloriesburntArray.get(0).toString());
                    Uri uri=getActivity().getContentResolver().insert(MyContentProvider.CONTENT_URI, values);
                    workoutNum=r.averageweeklyworkoutnumberArray.get(0)+1;
                    r.averageweeklyworkoutnumberArray.set(0, workoutNum);
                    r.alltimeworkoutnumberArray.set(0, workoutNum);
                    // Toast.makeText(getBaseContext(), "New Record inserted", Toast.LENGTH_LONG).show(
                    //  String URL="content://com.example.vishwa.homework2app.MyContentProvider";
                    //  Uri id=Uri.parse(URL);
                    //  Cursor c=managedQuery(id, null, null, null, "id");
                    // c.getString(c.getColumnIndex(MyContentProvider.name));
                    //getActivity().stopService(new Intent(getActivity(), MyService.class));
                    //handler.removeCallbacks(updateTimer);
                 /*   startTime=0L;
                    timeInMilliseconds=0L;
                    timeSwapBuff=0L;
                    updatedTime=0L;
                    secs=0;
                    mins=0;
                    milliseconds=0;
                    handler.removeCallbacks(updateTimer);
                    timerValue.setText("00:00:00");
                    */


                    //  r.customHandler=new Handler();
                    //  Intent intent = new Intent(portraitFragment.this, RecordWorkout.class);
                    // startActivity(intent);

                    // workoutButton.setText("start workout");

                }
            }
        });




        return view;
    }




    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);

        final Button workoutButton = (Button) view.findViewById(R.id.workoutButton);
        if (workoutButton.getText().toString().equalsIgnoreCase("stop workout")) {

            MapFragment fragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            fragment.getMapAsync(this);
        }


    }


    Runnable updateTimer = new Runnable() {

        public void run() {

            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;

            updatedTime = timeSwapBuff + timeInMilliseconds;

            secs = (int) (updatedTime / 1000);

            mins = secs / 60;

            secs = secs % 60;

            milliseconds = (int) (updatedTime % 1000);

            timerValue.setText("" + mins + ":"

                    + String.format("%02d", secs) + ":"

                    + String.format("%03d", milliseconds));

            timerValue.setTextColor(Color.RED);
            r.averageweeklyminuteArray.set(0, mins);
            r.alltimeminuteArray.set(0, mins);
            r.averageweeklysecondArray.set(0, secs);
            r.alltimesecondArray.set(0, secs);
            r.millisecondsArray.set(0, milliseconds);

            handler.postDelayed(this, 0);

        }

    };



    public void redrawLine() {
        PolylineOptions options = new PolylineOptions().width(5).color(Color.BLUE).geodesic(true);
        for (int i = 0; i < r.points.size(); i++) {
            LatLng point = r.points.get(i);
            options.add(point);
        }
        line = mMap.addPolyline(options);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {


        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            redrawLine();
        }


/*
          //  googleMap.getUiSettings().setZoomControlsEnabled(true);
          //  googleMap.getUiSettings().setCompassEnabled(true);
         //   googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        //    googleMap.getUiSettings().setZoomGesturesEnabled(true);
        //    googleMap.getUiSettings().setRotateGesturesEnabled(true);

        // LocationManager locationManager;
         //locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
       // String locationProvider = locationManager.getBestProvider(criteria, true);

        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Location location = locationManager.getLastKnownLocation(locationProvider);
        String label = "Address:";
        List<Address> addresses;


        try {
            Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (addresses != null) {
                Address address = addresses.get(0);
                StringBuilder stringBuilder = new StringBuilder("");
                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                    stringBuilder.append(address.getAddressLine(i)).append("/");
                }
                label = label + stringBuilder.toString();
            }

        } catch (IOException e) {

        }


        //  LatLng here = new LatLng(location.getLatitude(), location.getLongitude());
        LatLng here = new LatLng(37.279518, -121.867905);
        mMap.addMarker(new MarkerOptions().position(here).title(label));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(here, 10));
        mMap.setMyLocationEnabled(true);


        //    }
        */

    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        Sensor sensor = event.sensor;
        float[] values = event.values;
        double value = -1;
        double calories=0;

        if (values.length > 0) {
            value =(double) values[0]/2112;
            calories=(double) values[0]/20;
            r.averageweeklydistanceArray.set(0, value);
            r.alltimedistanceArray.set(0, value);
            r.averageweeklycaloriesburntArray.set(0, calories);
            r.alltimecaloriesburntArray.set(0, calories);


        }

        if (sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            distance.setText(r.averageweeklydistanceArray.get(0).toString());
        } else if (sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {

            distance.setText("Step Detector Detected : " +r.averageweeklydistanceArray.get(0).toString());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }



    @Override
    public void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mStepCounterSensor,

                SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(this, mStepDetectorSensor,

                SensorManager.SENSOR_DELAY_FASTEST);
        if (workoutButton.getText().toString().equalsIgnoreCase("stop workout")) {
            if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(locationProvider, 400, 1, this);
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        LatLng here = new LatLng(location.getLatitude(), location.getLongitude());
        // mMap.addMarker(new MarkerOptions().position(here).title("Marker"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(here, 17));
        r.points.add(here);
        redrawLine();

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    @Override
    public void onPause() {
        super.onPause();
        if (workoutButton.getText().toString().equalsIgnoreCase("stop workout")) {
            if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.removeUpdates(this);
            }
        }


    }
    @Override
    public void onStop() {
        super.onStop();
        mSensorManager.unregisterListener(this, mStepCounterSensor);
        mSensorManager.unregisterListener(this, mStepDetectorSensor);
    }
}
