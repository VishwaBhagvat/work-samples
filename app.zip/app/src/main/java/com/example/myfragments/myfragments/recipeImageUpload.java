package com.example.myfragments.myfragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class recipeImageUpload extends AppCompatActivity {


    public static Button submit2;
    public static Button localFileImageButton;
    // ImageView img;
    public static EditText imageUrl;
    public static ImageView img;
    public static Bitmap bitmap;
    public static ProgressDialog pDialog;
private MainActivity m2;
    private newdish n1;
    private EditScreen e;
    private static int RESULT_LOAD_IMAGE = 1;
    public static int select5;
    public static int noAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_image_upload);

        img = (ImageView) findViewById(R.id.recipeimage);
        submit2 = (Button) findViewById(R.id.submit2);
        imageUrl = (EditText) findViewById(R.id.imageUrl);
        localFileImageButton = (Button) findViewById(R.id.localImage);



        submit2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                m2.up = 1;
                if(n1.intentWhere==0)
                {
                    noAdd=1;
                    n1.internetUrlImages.set(n1.internetUrlImages.size()-1, imageUrl.getText().toString());
                    Intent intent = new Intent(recipeImageUpload.this, newdish.class);
                    startActivity(intent);
                }
                else if (n1.intentWhere==1)
                {
                    //e.index2015=1;

                    n1.internetUrlImages.set(n1.internetUrlImages.size()-1, imageUrl.getText().toString());
                    Intent intent1 = new Intent(recipeImageUpload.this, EditScreen.class);
                    startActivity(intent1);
                }


            }
        });

        localFileImageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);

            }
        });


    }
/*

    private class LoadImage extends AsyncTask<String, String, Bitmap> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(recipeImageUpload.this);
            pDialog.setMessage("Loading Image ....");
            pDialog.show();

        }

        protected Bitmap doInBackground(String... args) {
            try {
                bitmap = BitmapFactory.decodeStream((InputStream) new URL(args[0]).getContent());

            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onPostExecute(Bitmap image) {

            if (image != null) {
                img.setImageBitmap(image);
                img.setMaxHeight(0);
                img.setMaxWidth(1);
                pDialog.dismiss();

            } else {

                pDialog.dismiss();
                Toast.makeText(recipeImageUpload.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();

            }
        }
        */
    }












