package com.example.myfragments.myfragments;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class lunch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lunch);

        Button mondayLunch= (Button) findViewById(R.id.mondayLunch);
        mondayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, mondayLunch.class);
                startActivity(intent);
            }
        });

        Button tuesdayLunch= (Button) findViewById(R.id.tuesdayLunch);
        tuesdayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, tuesdayLunch.class);
                startActivity(intent);
            }
        });
        Button wednesdayLunch= (Button) findViewById(R.id.wednesdayLunch);
        wednesdayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, wednesdayLunch.class);
                startActivity(intent);
            }
        });

        Button thursdayLunch= (Button) findViewById(R.id.thursdayLunch);
        thursdayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, thursdayLunch.class);
                startActivity(intent);
            }
        });

        Button fridayLunch= (Button) findViewById(R.id.fridayLunch);
        fridayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, fridayLunch.class);
                startActivity(intent);
            }
        });
        Button saturdayLunch= (Button) findViewById(R.id.saturdayLunch);
        saturdayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, saturdayLunch.class);
                startActivity(intent);
            }
        });

        Button sundayLunch= (Button) findViewById(R.id.sundayLunch);
        sundayLunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(lunch.this, sundayLunch.class);
                startActivity(intent);
            }
        });

    }
}
