package com.example.myfragments.myfragments;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class wednesdayLunch extends AppCompatActivity {


    public static int select5;
    private mealScreen1 m1;
    public static String itemName9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wednesday_lunch);




        final ListView listView = (ListView) findViewById(R.id.wednesdaylunchlist);

        // Create a List from String Array elements


        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, m1.WednesdaylunchMeals)
        {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);

                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 500;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);
        if (listView.getCount() == 0)
        {
            Intent intent = new Intent(wednesdayLunch.this, eatingOut.class);
            startActivity(intent);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id)
            {


                itemName9=listView.getItemAtPosition(pos).toString();
                arrayAdapter.remove(itemName9);
                arrayAdapter.notifyDataSetChanged();
                if (arrayAdapter.getCount() == 0)
                {
                    Intent intent = new Intent(wednesdayLunch.this, eatingOut.class);
                    startActivity(intent);
                }


            }
        });
    }
}
