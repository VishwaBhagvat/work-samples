package com.example.myfragments.myfragments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class eatingOut extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eating_out);
    }
}
