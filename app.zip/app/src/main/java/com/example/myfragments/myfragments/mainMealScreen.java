package com.example.myfragments.myfragments;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class mainMealScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_meal_screen);

        Button breakfast = (Button) findViewById(R.id.breakfastButton);
        Button lunch= (Button) findViewById(R.id.lunchButton);
        Button dinner= (Button) findViewById(R.id.dinnerButton);
        breakfast.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mainMealScreen.this, breakfast.class);
                startActivity(intent);
            }
        });

        lunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mainMealScreen.this, lunch.class);
                startActivity(intent);
            }
        });

        dinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mainMealScreen.this, dinner.class);
                startActivity(intent);

            }
        });











    }
}
