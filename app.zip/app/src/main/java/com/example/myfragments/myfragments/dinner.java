package com.example.myfragments.myfragments;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class dinner extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinner);

        Button mondaydinner = (Button) findViewById(R.id.mondayDinner);
        mondaydinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, mondayDinner.class);
                startActivity(intent);
            }
        });

        Button tuesdaydinner = (Button) findViewById(R.id.tuesdayDinner);
        tuesdaydinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, tuesdayDinner.class);
                startActivity(intent);
            }
        });
        Button wednesdaydinner = (Button) findViewById(R.id.wednesdayDinner);
        wednesdaydinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, wednesdayDinner.class);
                startActivity(intent);
            }
        });

        Button thursdayDinner = (Button) findViewById(R.id.thursdayDinner);
        thursdayDinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, thursdayDinner.class);
                startActivity(intent);
            }
        });

        Button fridayDinner = (Button) findViewById(R.id.fridayDinner);
        fridayDinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, fridayDinner.class);
                startActivity(intent);
            }
        });
        Button saturdayDinner = (Button) findViewById(R.id.saturdayDinner);
        saturdayDinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, saturdayDinner.class);
                startActivity(intent);
            }
        });

        Button sundayDinner = (Button) findViewById(R.id.sundayDinner);
        sundayDinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(dinner.this, sundayDinner.class);
                startActivity(intent);
            }
        });
    }
}