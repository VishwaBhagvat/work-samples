package com.example.myfragments.myfragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myfragments.myfragments.recipeImageUpload;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class newdish extends Activity
{
   private recipeImageUpload I;
    Spinner sp;
    Spinner sp1;
    Spinner sp2;
    Spinner sp3;
    Spinner sp4;
    Spinner sp5;
    Spinner sp6;
    Spinner sp7;
    Spinner sp8;
    Spinner sp9;

    Button upload;
    ImageView recipeImage;
    ImageView recipeImage1;
    Bitmap bitmap;
    ProgressDialog pDialog;
      recipeImageUpload a;
    private MainActivity m;

    public static int intentWhere=0;
    public static int submit=0;
    private recipe w;
    private EditScreen e;
    // public ArrayList<String> recipes=new ArrayList<String>();
    public static ArrayAdapter<String> adapter; //new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item , ingredients);
   public static ArrayList<String> ingredients=new ArrayList<String>(Arrays.asList("other", "apple", "flour", "banana"));
    public static ArrayList<String> cookDirections=new ArrayList<String>();
    public static ArrayList<String> cookItems=new ArrayList<String>();
    public static ArrayList<Bitmap> imageArray = new ArrayList<Bitmap>();
    public static ArrayList<String> internetUrlImages=new ArrayList<String>();
    public static ArrayList<Integer> countItem=new ArrayList<Integer>();
    public static ArrayList<String> cookItemsNoDuplicates=new ArrayList<String>();
    public static int imageArrayEmpty=0;

    public  int count1=1;
    public int count2=1;
    public  int count3=1;
    public  int count4=1;
    public  int count5=1;
    public  int count6=1;
    public  int count7=1;
    public  int count8=1;
    public  int count9=1;
    public  int count10=1;





    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newdish);

      countItem.add(count1);
        countItem.add(count2);
        countItem.add(count3);
        countItem.add(count4);
        countItem.add(count5);
        countItem.add(count6);
        countItem.add(count7);
        countItem.add(count8);
        countItem.add(count9);
        countItem.add(count10);


        if(a.noAdd==0)
        {
            internetUrlImages.add("https://authoritynutrition.com/wp-content/uploads/2013/01/fruits.jpg");
        }
        final EditText recipeText= (EditText) findViewById(R.id.recipeName);



        final EditText cookingDirections= (EditText) findViewById(R.id.directions);
        final EditText item1= (EditText) findViewById(R.id.item1text);
        final EditText item2= (EditText) findViewById(R.id.item2text);
        final EditText item3= (EditText) findViewById(R.id.item3text);
        final EditText item4= (EditText) findViewById(R.id.item4text);
        final EditText item5= (EditText) findViewById(R.id.item5text);
        final EditText item6= (EditText) findViewById(R.id.item6text);
        final EditText item7= (EditText) findViewById(R.id.item7text);
        final EditText item8= (EditText) findViewById(R.id.item8text);
        final EditText item9= (EditText) findViewById(R.id.item9text);
        final EditText item10= (EditText) findViewById(R.id.item10text);
        //final ImageView recipeImage=(ImageView) findViewById(R.id.recipeimage);
       // final ImageButton uploadImageButton=(ImageButton) findViewById(R.id.recipeTypeButton);







        upload=(Button)findViewById(R.id.imageupload);
        recipeImage= (ImageView)findViewById(R.id.recipeimage);
        recipeImage1=(ImageView)findViewById(R.id.recipeimage1);
        upload.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                intentWhere=0;
                Intent intent = new Intent(newdish.this, recipeImageUpload.class);
                startActivity(intent);

            }
        });


           if(m.up==0) {
               new LoadImage().execute("https://authoritynutrition.com/wp-content/uploads/2013/01/fruits.jpg");

           }
        if(m.up==1)
          {
              new LoadImage().execute(a.imageUrl.getText().toString());




           }



































    recipeText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && recipeText.getText().toString().length() > 0) {
                    if (w.recipes.contains(recipeText.getText().toString().toLowerCase())) {
                        Context context = getApplicationContext();
                        CharSequence text = "Duplicate recipies not allowed";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();


                    }
                    else
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Recipe ok";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            }
        });



















        item1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                                           @Override
                                           public void onFocusChange(View v, boolean hasFocus) {
                                               item1.toString().toLowerCase();
                                               if (!hasFocus && item1.getText().toString().length() > 0) {
                                                   if (!ingredients.contains(item1.getText().toString().toLowerCase())) {
                                                       ingredients.add(item1.getText().toString().toLowerCase());
                                                     //  adapter.add(item1.getText().toString().toLowerCase());
                                                       adapter.notifyDataSetChanged();
                                                   }
                                               }
                                           }
                                       });


        item2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item2.toString().toLowerCase();
                if (!hasFocus && item2.getText().toString().length() > 0) {
                    if (!ingredients.contains(item2.getText().toString().toLowerCase())) {
                        ingredients.add(item2.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item3.toString().toLowerCase();
                if (!hasFocus && item3.getText().toString().length() > 0) {
                    if (!ingredients.contains(item3.getText().toString().toLowerCase())) {
                        ingredients.add(item3.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item2.toString().toLowerCase();
                if (!hasFocus && item4.getText().toString().length() > 0) {
                    if (!ingredients.contains(item4.getText().toString().toLowerCase())) {
                        ingredients.add(item4.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item5.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item5.toString().toLowerCase();
                if (!hasFocus && item5.getText().toString().length() > 0) {
                    if (!ingredients.contains(item5.getText().toString().toLowerCase())) {
                        ingredients.add(item5.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item6.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item6.toString().toLowerCase();
                if (!hasFocus && item6.getText().toString().length() > 0) {
                    if (!ingredients.contains(item6.getText().toString().toLowerCase())) {
                        ingredients.add(item6.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item7.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item7.toString().toLowerCase();
                if (!hasFocus && item7.getText().toString().length() > 0) {
                    if (!ingredients.contains(item7.getText().toString().toLowerCase())) {
                        ingredients.add(item7.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item8.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item8.toString().toLowerCase();
                if (!hasFocus && item8.getText().toString().length() > 0) {
                    if (!ingredients.contains(item8.getText().toString().toLowerCase())) {
                        ingredients.add(item8.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item9.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item9.toString().toLowerCase();
                if (!hasFocus && item9.getText().toString().length() > 0) {
                    if (!ingredients.contains(item9.getText().toString().toLowerCase())) {
                        ingredients.add(item9.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item10.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item10.toString().toLowerCase();
                if (!hasFocus && item10.getText().toString().length() > 0) {
                    if (!ingredients.contains(item10.getText().toString().toLowerCase())) {
                        ingredients.add(item10.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        });






















        Button b1;
        b1 = (Button) findViewById(R.id.submit);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (recipeText.getText().toString().length() > 0) {      //recipes
                    if (!w.recipes.contains(recipeText.getText().toString().toLowerCase())) {

                        Context context = getApplicationContext();
                        CharSequence text = "Recipe added";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();

                        w.recipes.add(recipeText.getText().toString().toLowerCase());
                        cookDirections.add(cookingDirections.getText().toString());
                        e.cookDirectionsEdit.add(cookingDirections.getText().toString());
                        e.cookItemsEdit.add(item1.getText().toString());
                        e.cookItemsEdit.add(item2.getText().toString());
                        e.cookItemsEdit.add(item3.getText().toString());
                        e.cookItemsEdit.add(item4.getText().toString());
                        e.cookItemsEdit.add(item5.getText().toString());
                        e.cookItemsEdit.add(item6.getText().toString());
                        e.cookItemsEdit.add(item7.getText().toString());
                        e.cookItemsEdit.add(item8.getText().toString());
                        e.cookItemsEdit.add(item9.getText().toString());
                        e.cookItemsEdit.add(item10.getText().toString());



                        if(cookItems.contains(item1.getText().toString().toLowerCase()))
                        {
                            int a=cookItems.indexOf(item1.getText().toString().toLowerCase());
                             countItem.set(a, countItem.get(a)+1 );

                        }
                        cookItems.add(item1.getText().toString().toLowerCase());
                        if(cookItems.contains(item2.getText().toString().toLowerCase()))
                        {
                            int b=cookItems.indexOf(item2.getText().toString().toLowerCase());
                            countItem.set(b, countItem.get(b)+1);
                        }
                        cookItems.add(item2.getText().toString().toLowerCase());
                        if(cookItems.contains(item3.getText().toString().toLowerCase()))
                        {
                            int c=cookItems.indexOf(item3.getText().toString().toLowerCase());
                            countItem.set(c, countItem.get(c)+1);
                        }

                        cookItems.add(item3.getText().toString().toLowerCase());
                        if(cookItems.contains(item4.getText().toString().toLowerCase()))
                        {
                            int d=cookItems.indexOf(item4.getText().toString().toLowerCase());
                            countItem.set(d, countItem.get(d)+1);
                        }
                        cookItems.add(item4.getText().toString().toLowerCase());
                        if(cookItems.contains(item5.getText().toString().toLowerCase()))
                        {
                            int e=cookItems.indexOf(item5.getText().toString().toLowerCase());
                            countItem.set(e, countItem.get(e)+1);
                        }
                        cookItems.add(item5.getText().toString().toLowerCase());
                        if(cookItems.contains(item6.getText().toString().toLowerCase()))
                        {
                            int f=cookItems.indexOf(item6.getText().toString().toLowerCase());
                             countItem.set(f, countItem.get(f)+1);
                        }
                        cookItems.add(item6.getText().toString().toLowerCase());
                        if(cookItems.contains(item7.getText().toString().toLowerCase()))
                        {
                            int g=cookItems.indexOf(item7.getText().toString().toLowerCase());
                            countItem.set(g, countItem.get(g)+1);
                        }
                        cookItems.add(item7.getText().toString().toLowerCase());
                        if(cookItems.contains(item8.getText().toString().toLowerCase()))
                        {
                            int h=cookItems.indexOf(item8.getText().toString().toLowerCase());
                             countItem.set(h, countItem.get(h)+1);
                        }
                        cookItems.add(item8.getText().toString().toLowerCase());
                        if(cookItems.contains(item9.getText().toString().toLowerCase()))
                        {
                            int i=cookItems.indexOf(item9.getText().toString().toLowerCase());
                            countItem.set(i, countItem.get(i)+1);
                        }
                        cookItems.add(item9.getText().toString().toLowerCase());
                        if(cookItems.contains(item10.getText().toString().toLowerCase()))
                        {
                            int j=cookItems.indexOf(item10.getText().toString().toLowerCase());
                           countItem.set(j, countItem.get(j)+1);
                        }
                        cookItems.add(item10.getText().toString().toLowerCase());


                        if(!cookItemsNoDuplicates.contains(item1.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item1.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item2.getText().toString().toLowerCase()))
                        {
                            cookItemsNoDuplicates.add(item2.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item3.getText().toString().toLowerCase()))
                        {
                            cookItemsNoDuplicates.add(item3.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item4.getText().toString().toLowerCase())) {

                            cookItemsNoDuplicates.add(item4.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item5.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item5.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item6.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item6.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item7.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item7.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item8.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item8.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item9.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item9.getText().toString().toLowerCase());
                        }
                        if(!cookItemsNoDuplicates.contains(item10.getText().toString().toLowerCase()))
                        {

                            cookItemsNoDuplicates.add(item10.getText().toString().toLowerCase());
                        }







                        count1=1;
                        count2=1;
                        count3=1;
                        count4=1;
                        count5=1;
                        count6=1;
                        count7=1;
                        count8=1;
                        count9=1;
                        count10=1;
                        submit=1;

                        Intent intent = new Intent(newdish.this, MainActivity.class);
                        startActivity(intent);


                    } else {
                        Context context = getApplicationContext();
                        CharSequence text = "Recipe not added.  Cannot have duplicate recipe names";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            }
        });















        sp = (Spinner) findViewById(R.id.item1);
        final EditText et1= (EditText) findViewById(R.id.item1text);

        sp1 = (Spinner) findViewById(R.id.item2);
        final EditText et2= (EditText) findViewById(R.id.item2text);

        sp2 = (Spinner) findViewById(R.id.item3);
        final EditText et3= (EditText) findViewById(R.id.item3text);

        sp3 = (Spinner) findViewById(R.id.item4);
        final EditText et4= (EditText) findViewById(R.id.item4text);

        sp4 = (Spinner) findViewById(R.id.item5);
        final EditText et5= (EditText) findViewById(R.id.item5text);

        sp5 = (Spinner) findViewById(R.id.item6);
        final EditText et6= (EditText) findViewById(R.id.item6text);

        sp6 = (Spinner) findViewById(R.id.item7);
        final EditText et7= (EditText) findViewById(R.id.item7text);

        sp7 = (Spinner) findViewById(R.id.item8);
        final EditText et8= (EditText) findViewById(R.id.item8text);

        sp8 = (Spinner) findViewById(R.id.item9);
        final EditText et9= (EditText) findViewById(R.id.item9text);

        sp9 = (Spinner) findViewById(R.id.item10);
        final EditText et10= (EditText) findViewById(R.id.item10text);


        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item , ingredients);
        sp.setAdapter(adapter);
        sp1.setAdapter(adapter);
        sp2.setAdapter(adapter);
        sp3.setAdapter(adapter);
        sp4.setAdapter(adapter);
        sp5.setAdapter(adapter);
        sp6.setAdapter(adapter);
        sp7.setAdapter(adapter);
        sp8.setAdapter(adapter);
        sp9.setAdapter(adapter);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {
                //  Toast.makeText(getBaseContext(), sp.getSelectedItem().toString(),
                //       Toast.LENGTH_LONG).show();
                if(sp.getSelectedItem().toString().equals("other")) {
                    et1.setEnabled(true);
                    if (!ingredients.contains(et1.getText().toString())) {
                        ingredients.add(et1.getText().toString());

                        adapter.add(et1.getText().toString());
                        adapter.notifyDataSetChanged();

                    }
                }
                else
                {
                    et1.setText(sp.getSelectedItem().toString());
                    et1.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });

        if(!ingredients.contains(et1.getText().toString()))
        {
            ingredients.add(et1.getText().toString());
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item , ingredients);
            sp1.setAdapter(adapter);

        }
        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {



            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp1.getSelectedItem().toString().equals("other")) {
                    et2.setEnabled(true);
                    if (!ingredients.contains(et2.getText().toString())) {
                        ingredients.add(et2.getText().toString());
                        adapter.add(et2.getText().toString());
                        adapter.notifyDataSetChanged();
                    }
                }
                else {
                    et2.setText(sp1.getSelectedItem().toString());
                    et2.setEnabled(false);
                }
            }


            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });

        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {

                if(sp2.getSelectedItem().toString().equals("other"))
                {
                    et3.setEnabled(true);
                }
                else
                {
                    et3.setText(sp2.getSelectedItem().toString());
                    et3.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });
        sp3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {

                if(sp3.getSelectedItem().toString().equals("other"))
                {
                    et4.setEnabled(true);
                }
                else
                {
                    et4.setText(sp3.getSelectedItem().toString());
                    et4.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });
        sp4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {

                if(sp4.getSelectedItem().toString().equals("other"))
                {

                    et5.setEnabled(true);
                }
                else
                {
                    et5.setText(sp4.getSelectedItem().toString());
                    et5.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });
        sp5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {

                if(sp5.getSelectedItem().toString().equals("other"))
                {
                    et6.setEnabled(true);
                }
                else
                {
                    et6.setText(sp5.getSelectedItem().toString());
                    et6.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });

        sp6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {

                if(sp6.getSelectedItem().toString().equals("other"))
                {
                    et7.setEnabled(true);
                }
                else
                {
                    et7.setText(sp6.getSelectedItem().toString());
                    et7.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });
        sp7.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {
              /*  Toast.makeText(getBaseContext(), sp7.getSelectedItem().toString(),
                        Toast.LENGTH_LONG).show();
                        */
                if(sp7.getSelectedItem().toString().equals("other"))
                {
                    et8.setEnabled(true);
                }
                else
                {
                    et8.setText(sp7.getSelectedItem().toString());
                    et8.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });

        sp8.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {
          /*      Toast.makeText(getBaseContext(), sp6.getSelectedItem().toString(),
                        Toast.LENGTH_LONG).show();
                        */
                if(sp8.getSelectedItem().toString().equals("other"))
                {
                    et9.setEnabled(true);
                }
                else
                {
                    et9.setText(sp8.getSelectedItem().toString());
                    et9.setEnabled(false);
                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });
        sp9.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3)
            {
               /* Toast.makeText(getBaseContext(), sp9.getSelectedItem().toString(),
                        Toast.LENGTH_LONG).show();
                        */
                if(sp9.getSelectedItem().toString().equals("other"))
                {
                    et10.setEnabled(true);
                }
                else
                {
                    et10.setText(sp9.getSelectedItem().toString());
                    et10.setEnabled(false);

                }
            }
            public void onNothingSelected(AdapterView<?> arg0)
            {
                // TODO Auto-generated method stub
            }
        });










    }
    public ArrayList<String> getList()
    {
        return cookItems;
    }

    private class LoadImage extends AsyncTask<String, String, Bitmap> {

        private recipe w1;
        private MainActivity m1;
        @Override
       protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(newdish.this);
            pDialog.setMessage("Loading Image ....");
            pDialog.show();

        }
        protected Bitmap doInBackground(String... args) {
            try {
                bitmap = BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onPostExecute(Bitmap image) {

            if(image != null){


                recipeImage.setMaxHeight(0);
                recipeImage.setMaxWidth(1);

                //if(m1.up==0) {
                    if(imageArray.size()==0)
                    {
                        imageArray.add(image);
                        recipeImage.setImageBitmap(image);
                    }
                    else
                    {
                        imageArray.add(image);
                        recipeImage.setImageBitmap(image);
                    }
               // }
               // else
               // {


                  //          imageArray.set(imageArray.size() - 1, image);
                  //           recipeImage.setImageBitmap(image);




              //  }
              //      m.up=0;


                pDialog.dismiss();

            }
            else{
                pDialog.dismiss();
                Toast.makeText(newdish.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();




            }
        }
    }




}



