package com.example.myfragments.myfragments;


import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

//import com.example.myfragments.myfragments.EditScreen;
import com.example.myfragments.myfragments.newdish;

import java.util.ArrayList;
//import com.example.vishwa.whatsfordinner.PortraitFragment;


public class recipe extends Activity
{

    public static String j;
    private newdish n;
    private EditScreen e;
    int i = 0;
    public static int k=0;
    public static String str;
    public static int select;
    public ArrayList<String> mealPlan = new ArrayList<String>();


    public static  ArrayList<String> recipes = new ArrayList<String>();
    //final EditText recipeField= (EditText) findViewById(R.id.recipeName);


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        // no more this
        setContentView(R.layout.activity_recipe);
        Configuration config = getResources().getConfiguration();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
           LandscapeFragment landscapeFragment = new LandscapeFragment();
             fragmentTransaction.replace(android.R.id.content, landscapeFragment);
       } else
        {
            PortraitFragment portraitFragment = new PortraitFragment();
             fragmentTransaction.replace(android.R.id.content, portraitFragment);


       }
        fragmentTransaction.commit();


        final ListView listView = (ListView) findViewById(R.id.lv);
        // Create a List from String Array elements


        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, recipes) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);

                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 500;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);



        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
        {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {

                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);
                str=listView.getItemAtPosition(pos).toString().toLowerCase();


                select=pos;//listView.getSelectedItemPosition();
                // recipes.remove(select);
                // e.recipeTextEdit.setText(str);

                Intent intent = new Intent(recipe.this, EditScreen.class);
                startActivity(intent);
                //  j=listView.getSelectedItem().toString();
                return true;
            }
        });
    }
}



