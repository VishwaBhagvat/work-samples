package com.example.myfragments.myfragments;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;

public class mealScreen1 extends Activity {

    Spinner spMeal;
    private recipe rMeal;
    public static ArrayList<String> mealPlanner=new ArrayList<String>(Arrays.asList("breakfast", "lunch", "dinner"));
    public static ArrayList<String> MondaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> MondaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> MondaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> TuesdaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> TuesdaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> TuesdaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> WednesdaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> WednesdaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> WednesdaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> ThursdaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> ThursdaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> ThursdaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> FridaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> FridaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> FridaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> SaturdaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> SaturdaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> SaturdaydinnerMeals=new ArrayList<String>();
    public static ArrayList<String> SundaybreakfastMeals=new ArrayList<String>();
    public static ArrayList<String> SundaylunchMeals=new ArrayList<String>();
    public static ArrayList<String> SundaydinnerMeals=new ArrayList<String>();
    public static ArrayAdapter<String> adapterMeal;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_screen1);
        spMeal = (Spinner) findViewById(R.id.mealScreen1Spinner);
       adapterMeal = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item , mealPlanner);
        spMeal.setAdapter(adapterMeal);
        Button meal=(Button)findViewById(R.id.mealButton);
        meal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                if(spMeal.getSelectedItem().toString().equals("breakfast"))
                {
                    MondaybreakfastMeals.add(rMeal.str.toString());
                    TuesdaybreakfastMeals.add(rMeal.str.toString());
                    WednesdaybreakfastMeals.add(rMeal.str.toString());
                    ThursdaybreakfastMeals.add(rMeal.str.toString());
                    FridaybreakfastMeals.add(rMeal.str.toString());
                    SaturdaybreakfastMeals.add(rMeal.str.toString());
                    SundaybreakfastMeals.add(rMeal.str.toString());
                    Intent intent = new Intent(mealScreen1.this, MainActivity.class);
                  startActivity(intent);

            }
               else if(spMeal.getSelectedItem().toString().equals("lunch"))
                {

                    MondaylunchMeals.add(rMeal.str.toString());
                    TuesdaylunchMeals.add(rMeal.str.toString());
                    WednesdaylunchMeals.add(rMeal.str.toString());
                    ThursdaylunchMeals.add(rMeal.str.toString());
                    FridaylunchMeals.add(rMeal.str.toString());
                    SaturdaylunchMeals.add(rMeal.str.toString());
                    SundaylunchMeals.add(rMeal.str.toString());
                    Intent intent = new Intent(mealScreen1.this, MainActivity.class);
                    startActivity(intent);

                }
               else if(spMeal.getSelectedItem().toString().equals("dinner"))
                {
                    MondaydinnerMeals.add(rMeal.str.toString());
                    TuesdaydinnerMeals.add(rMeal.str.toString());
                    WednesdaydinnerMeals.add(rMeal.str.toString());
                    ThursdaydinnerMeals.add(rMeal.str.toString());
                    FridaydinnerMeals.add(rMeal.str.toString());
                    SaturdaydinnerMeals.add(rMeal.str.toString());
                    SundaydinnerMeals.add(rMeal.str.toString());

                    Intent intent = new Intent(mealScreen1.this, MainActivity.class);
                    startActivity(intent);

                }
        }
        });

    }

}


