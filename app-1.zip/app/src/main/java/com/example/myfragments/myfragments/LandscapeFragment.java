package com.example.myfragments.myfragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class LandscapeFragment extends android.app.Fragment {

    private recipe r15;
    private newdish n15;


    public LandscapeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_landscape, container, false);

        final ListView listView = (ListView) view.findViewById(R.id.lv);
        final ImageView imageLandscape1=(ImageView) view.findViewById(R.id.imageLandscape);
        final TextView recipeNameLandscape=(TextView) view.findViewById(R.id.recipeNameLandscape);
        final TextView item1Landscape=(TextView) view.findViewById(R.id.item1Landscape);
        final TextView item2Landscape=(TextView) view.findViewById(R.id.item2Landscape);
        final TextView item3Landscape=(TextView) view.findViewById(R.id.item3Landscape);
        final TextView item4Landscape=(TextView) view.findViewById(R.id.item4Landscape);
        final TextView item5Landscape=(TextView) view.findViewById(R.id.item5Landscape);
        final TextView item6Landscape=(TextView) view.findViewById(R.id.item6Landscape);
        final TextView item7Landscape=(TextView) view.findViewById(R.id.item7Landscape);
        final TextView item8Landscape=(TextView) view.findViewById(R.id.item8Landscape);
        final TextView item9Landscape=(TextView) view.findViewById(R.id.item9Landscape);
        final TextView item10Landscape=(TextView) view.findViewById(R.id.item10Landscape);
        final TextView cookingDirectionsLandscape=(TextView) view.findViewById(R.id.cookingDirectionsLandscape);
        final TextView cookingDirectionsLandscape1=(TextView) view.findViewById(R.id.cookingDirectionsland);
        final TextView Ing=(TextView) view.findViewById(R.id.ing);





        // Create a List from String Array elements


        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_list_item_1, r15.recipes) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);

                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 200;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {

                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);
                r15.str = listView.getItemAtPosition(pos).toString().toLowerCase();

                r15.select = pos;//listView.getSelectedItemPosition();
                // recipes.remove(select);
                // e.recipeTextEdit.setText(str);

                //  Intent intent = new Intent(recipe.this, EditScreen.class);
                startActivity(new Intent(getActivity(), EditScreen.class));

                //  j=listView.getSelectedItem().toString();
                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {

                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);
                r15.str = listView.getItemAtPosition(pos).toString().toLowerCase();

                r15.select = pos;//listView.getSelectedItemPosition();
               imageLandscape1.setImageBitmap(n15.imageArray.get(pos));
                recipeNameLandscape.setText(r15.recipes.get(pos).toString());
                Ing.setText("INGREDIENTS");
               item1Landscape.setText(n15.cookItems.get(pos+(pos*9)).toString());

                item2Landscape.setText(n15.cookItems.get(pos+(pos*9+1)).toString());
               item3Landscape.setText(n15.cookItems.get(pos+(pos*9+2)).toString());
                item4Landscape.setText(n15.cookItems.get(pos+(pos*9+3)).toString());
                item5Landscape.setText(n15.cookItems.get(pos+(pos*9+4)).toString());
                item6Landscape.setText(n15.cookItems.get(pos+(pos*9+5)).toString());
                item7Landscape.setText(n15.cookItems.get(pos+(pos*9+6)).toString());
               item8Landscape.setText(n15.cookItems.get(pos+(pos*9+7)).toString());
                item9Landscape.setText(n15.cookItems.get(pos+(pos*9+8)).toString());
                item10Landscape.setText(n15.cookItems.get(pos+(pos*9+9)).toString());
                cookingDirectionsLandscape1.setText("COOKING DIRECTIONS");
                cookingDirectionsLandscape.setText(n15.cookDirections.get(pos).toString());



                // recipes.remove(select);
                // e.recipeTextEdit.setText(str);

                //  Intent intent = new Intent(recipe.this, EditScreen.class);
                //startActivity(new Intent(getActivity(), EditScreen.class));

                //  j=listView.getSelectedItem().toString();

            }
        });







        return view;
    }
public void change(String txt)
{


}
}








// Inflate the layout for this fragment
