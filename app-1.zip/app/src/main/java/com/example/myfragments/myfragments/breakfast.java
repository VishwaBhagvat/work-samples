package com.example.myfragments.myfragments;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class breakfast extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakfast);

        Button mondaybreakfast= (Button) findViewById(R.id.mondayBreakfast);
        mondaybreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, mondayBreakfast.class);
                startActivity(intent);
            }
        });
        Button tuesdayBreakfast= (Button) findViewById(R.id.tuesdayBreakfast);
        tuesdayBreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, tuesdayBreakfast.class);
                startActivity(intent);
            }
        });

        Button wednesdaybreakfast= (Button) findViewById(R.id.wednesdayBreakfast);
        wednesdaybreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, wednesdayBreakfast.class);
                startActivity(intent);
            }
        });
        Button thursdayBreakfast= (Button) findViewById(R.id.thursdayBreakfast);
        thursdayBreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, thursdayBreakfast.class);
                startActivity(intent);
            }
        });

        Button fridayBreakfast= (Button) findViewById(R.id.fridayBreakfast);
        fridayBreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, fridayBreakfast.class);
                startActivity(intent);
            }
        });
        Button saturdayBreakfast= (Button) findViewById(R.id.saturdayBreakfast);
        saturdayBreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, saturdayBreakfast.class);
                startActivity(intent);
            }
        });

        Button sundayBreakfast= (Button) findViewById(R.id.sundayBreakfast);
        sundayBreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(breakfast.this, sundayBreakfast.class);
                startActivity(intent);
            }
        });

    }
}
