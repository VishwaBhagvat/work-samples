package com.example.myfragments.myfragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

public class EditScreen extends Activity {

    Spinner spEdit;
    Spinner sp1Edit;
    Spinner sp2Edit;
    Spinner sp3Edit;
    Spinner sp4Edit;
    Spinner sp5Edit;
    Spinner sp6Edit;
    Spinner sp7Edit;
    Spinner sp8Edit;
    Spinner sp9Edit;



    private static recipe wEdit;
    private recipe wEdit1;
    public static recipe wEdit2;
    private static newdish n;
    private MainActivity m1;
    Bitmap bitmap;
    ProgressDialog pDialog;
    private recipeImageUpload r;

    // public ArrayList<String> recipes=new ArrayList<String>();

    public static ArrayList<String> cookDirectionsEdit = new ArrayList<String>();
    public static ArrayList<String> cookItemsEdit = new ArrayList<String>();
    public ImageView recipeImage1;
    //   public static int Select=wEdit.select;
    public static int Select15;
    public static int index2015=0;
    private recipeImageUpload riu;
    Button upload5;

    public EditText recipeTextEdit;

    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_screen);


        recipeImage1=(ImageView)findViewById(R.id.recipeimage1);

        // cookItemsEdit.add(ncookItems.get(0).toString());
        recipeTextEdit = (EditText) findViewById(R.id.recipeNameEdit);
        recipeTextEdit.setText(wEdit.str);
        // ArrayList<String> clone=n.getList();

        final int index = wEdit.recipes.indexOf(wEdit.str);
        //String aa=clone.get(index).toString();



        final EditText cookingDirections = (EditText) findViewById(R.id.directions1);
        final EditText item1Edit = (EditText) findViewById(R.id.item1textEdit);
        final EditText item2Edit = (EditText) findViewById(R.id.item2textEdit);
        final EditText item3Edit = (EditText) findViewById(R.id.item3textEdit);
        final EditText item4Edit = (EditText) findViewById(R.id.item4textEdit);
        final EditText item5Edit = (EditText) findViewById(R.id.item5textEdit);
        final EditText item6Edit = (EditText) findViewById(R.id.item6textEdit);
        final EditText item7Edit = (EditText) findViewById(R.id.item7textEdit);
        final EditText item8Edit = (EditText) findViewById(R.id.item8textEdit);
        final EditText item9Edit = (EditText) findViewById(R.id.item9textEdit);
        final EditText item10Edit = (EditText) findViewById(R.id.item10textEdit);
        upload5=(Button)findViewById(R.id.imageupload);

        upload5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                n.intentWhere=1;
                Intent intent = new Intent(EditScreen.this, recipeImageUpload.class);
                startActivity(intent);

            }
        });


        //  if(m1.up==0)
        //  {

        //      new LoadImage().execute("https://authoritynutrition.com/wp-content/uploads/2013/01/fruits.jpg");

        // }

        //   else if(m1.up==1)
        // {


        new LoadImage().execute(n.internetUrlImages.get(wEdit.select).toString());


        //  }





        //  }






        if (wEdit.select == 0) {

            //  recipeImage1.setImageBitmap(n.imageArray.get(0));
            item1Edit.setText(cookItemsEdit.get(0));
            item2Edit.setText(cookItemsEdit.get(1));
            item3Edit.setText(cookItemsEdit.get(2));
            item4Edit.setText(cookItemsEdit.get(3));
            item5Edit.setText(cookItemsEdit.get(4));
            item6Edit.setText(cookItemsEdit.get(5));
            item7Edit.setText(cookItemsEdit.get(6));
            item8Edit.setText(cookItemsEdit.get(7));
            item9Edit.setText(cookItemsEdit.get(8));
            item10Edit.setText(cookItemsEdit.get(9));
            cookingDirections.setText(cookDirectionsEdit.get(wEdit.select));
        } else {
            //recipeImage1.setImageBitmap(n.imageArray.get(wEdit.select));
            item1Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9)));
            item2Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 1)));
            item3Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 2)));
            item4Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 3)));
            item5Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 4)));
            item6Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 5)));
            item7Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 6)));
            item8Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 7)));
            item9Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 8)));
            item10Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 9)));
            cookingDirections.setText(cookDirectionsEdit.get(wEdit.select));

        }


        recipeTextEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && recipeTextEdit.getText().toString().length() > 0) {
                    if (!recipeTextEdit.getText().toString().equals(wEdit.str.toString().toLowerCase())) {
                        if (wEdit.recipes.contains(recipeTextEdit.getText().toString().toLowerCase())) {
                            Context context = getApplicationContext();
                            CharSequence text = "Duplicate recipies not allowed";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();


                        }
                        else
                        {
                            Context context = getApplicationContext();
                            CharSequence text = "Recipe ok";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        }
                    }
                    else
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Recipe ok";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            }
        });

        item1Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item1Edit.toString().toLowerCase();
                if (!hasFocus && item1Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item1Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item1Edit.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item2Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item2Edit.toString().toLowerCase();
                if (!hasFocus && item2Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item2Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item2Edit.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item3Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item3Edit.toString().toLowerCase();
                if (!hasFocus && item3Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item3Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item3Edit.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item4Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item4Edit.toString().toLowerCase();
                if (!hasFocus && item4Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item4Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item4Edit.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item5Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item5Edit.toString().toLowerCase();
                if (!hasFocus && item5Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item5Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item5Edit.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item6Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item6Edit.toString().toLowerCase();
                if (!hasFocus && item6Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item6Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item6Edit.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item7Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item7Edit.toString().toLowerCase();
                if (!hasFocus && item7Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item7Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item7Edit.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item8Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item8Edit.toString().toLowerCase();
                if (!hasFocus && item8Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item8Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item8Edit.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });

        item9Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item9Edit.toString().toLowerCase();
                if (!hasFocus && item9Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item9Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item9Edit.getText().toString().toLowerCase());
                        //  adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });


        item10Edit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                item10Edit.toString().toLowerCase();
                if (!hasFocus && item10Edit.getText().toString().length() > 0) {
                    if (!n.ingredients.contains(item10Edit.getText().toString().toLowerCase())) {
                        n.ingredients.add(item10Edit.getText().toString().toLowerCase());
                        // adapter.add(item1.getText().toString().toLowerCase());
                        n.adapter.notifyDataSetChanged();
                    }
                }
            }
        });







        Button b1Edit;
        b1Edit = (Button) findViewById(R.id.submit1);
        b1Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  wEdit.recipes.remove(wEdit.select);
                if (recipeTextEdit.getText().toString().length() > 0) {      //recipes

                    if (!recipeTextEdit.getText().toString().equals(wEdit.str.toString().toLowerCase())) {
                        if (!wEdit.recipes.contains(recipeTextEdit.getText().toString().toLowerCase())) {

                            Context context = getApplicationContext();
                            CharSequence text = "Recipe added";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();

                            wEdit.recipes.set(wEdit.select, recipeTextEdit.getText().toString().toLowerCase());


                            cookItemsEdit.set(wEdit.select + (wEdit.select * 9), item1Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 1)), item2Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 2), item3Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 3)), item4Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 4), item5Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 5)), item6Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 6), item7Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 7)), item8Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 8), item9Edit.getText().toString().toLowerCase());
                            cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 9)), item10Edit.getText().toString().toLowerCase());
                            cookDirectionsEdit.set(wEdit.select, cookingDirections.getText().toString());

                            item1Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9)));
                            item2Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 1))));
                            item3Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 2))));
                            item4Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 3))));
                            item5Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 4)));
                            item6Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 5))));
                            item7Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 6))));
                            item8Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 7))));
                            item9Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 9))));
                            item10Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 9))));
                            Intent intent = new Intent(EditScreen.this, MainActivity.class);
                            startActivity(intent);


                        }
                        else
                        {
                            Context context = getApplicationContext();
                            CharSequence text = "Recipe not added.  Cannot have duplicate recipe names";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        }
                    }
                    else if (recipeTextEdit.getText().toString().equals(wEdit.str.toString().toLowerCase())) {
                        Context context = getApplicationContext();
                        CharSequence text = "Recipe added";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();

                        wEdit.recipes.set(wEdit.select, recipeTextEdit.getText().toString().toLowerCase());


                        cookItemsEdit.set(wEdit.select + (wEdit.select * 9), item1Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 1)), item2Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 2), item3Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 3)), item4Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 4), item5Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 5)), item6Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 6), item7Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 7)), item8Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set(wEdit.select + (wEdit.select * 9 + 8), item9Edit.getText().toString().toLowerCase());
                        cookItemsEdit.set((wEdit.select + (wEdit.select * 9 + 9)), item10Edit.getText().toString().toLowerCase());
                        cookDirectionsEdit.set(wEdit.select, cookingDirections.getText().toString());

                        item1Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9)));
                        item2Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 1))));
                        item3Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 2))));
                        item4Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 3))));
                        item5Edit.setText(cookItemsEdit.get(wEdit.select + (wEdit.select * 9 + 4)));
                        item6Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 5))));
                        item7Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 6))));
                        item8Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 7))));
                        item9Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 9))));
                        item10Edit.setText(cookItemsEdit.get((wEdit.select + (wEdit.select * 9 + 9))));

                    }

                }
            }
        });


        spEdit = (Spinner) findViewById(R.id.item1Edit);
        final EditText et1Edit = (EditText) findViewById(R.id.item1textEdit);

        sp1Edit = (Spinner) findViewById(R.id.item2Edit);
        final EditText et2Edit = (EditText) findViewById(R.id.item2textEdit);

        sp2Edit = (Spinner) findViewById(R.id.item3Edit);
        final EditText et3Edit = (EditText) findViewById(R.id.item3textEdit);

        sp3Edit = (Spinner) findViewById(R.id.item4Edit);
        final EditText et4Edit = (EditText) findViewById(R.id.item4textEdit);

        sp4Edit = (Spinner) findViewById(R.id.item5Edit);
        final EditText et5Edit = (EditText) findViewById(R.id.item5textEdit);

        sp5Edit = (Spinner) findViewById(R.id.item6Edit);
        final EditText et6Edit = (EditText) findViewById(R.id.item6textEdit);

        sp6Edit = (Spinner) findViewById(R.id.item7Edit);
        final EditText et7Edit = (EditText) findViewById(R.id.item7textEdit);

        sp7Edit = (Spinner) findViewById(R.id.item8Edit);
        final EditText et8Edit = (EditText) findViewById(R.id.item8textEdit);

        sp8Edit = (Spinner) findViewById(R.id.item9Edit);
        final EditText et9Edit = (EditText) findViewById(R.id.item9textEdit);

        sp9Edit = (Spinner) findViewById(R.id.item10Edit);
        final EditText et10Edit = (EditText) findViewById(R.id.item10textEdit);


        // adapterEdit = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ingredients1);
        spEdit.setAdapter(n.adapter);
        sp1Edit.setAdapter(n.adapter);
        sp2Edit.setAdapter(n.adapter);
        sp3Edit.setAdapter(n.adapter);
        sp4Edit.setAdapter(n.adapter);
        sp5Edit.setAdapter(n.adapter);
        sp6Edit.setAdapter(n.adapter);
        sp7Edit.setAdapter(n.adapter);
        sp8Edit.setAdapter(n.adapter);
        sp9Edit.setAdapter(n.adapter);

        spEdit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                //  Toast.makeText(getBaseContext(), sp.getSelectedItem().toString(),
                //       Toast.LENGTH_LONG).show();
                if (spEdit.getSelectedItem().toString().equals("other")) {
                    et1Edit.setEnabled(true);
                    if (!n.ingredients.contains(et1Edit.getText().toString())) {
                        n.ingredients.add(et1Edit.getText().toString());
                        n.adapter.add(et1Edit.getText().toString());
                        n.adapter.notifyDataSetChanged();


                    }
                }
                else {
                    et1Edit.setText(spEdit.getSelectedItem().toString());
                    et1Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        if(!n.ingredients.contains(et1Edit.getText().toString()))
        {
            n.ingredients.add(et1Edit.getText().toString());
            n.adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item , n.ingredients);
            sp1Edit.setAdapter(n.adapter);

        }
        sp1Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp1Edit.getSelectedItem().toString().equals("other")) {
                    et2Edit.setEnabled(true);
                    if (!n.ingredients.contains(et2Edit.getText().toString())) {
                        n.ingredients.add(et2Edit.getText().toString());
                        n.adapter.add(et2Edit.getText().toString());
                        n.adapter.notifyDataSetChanged();

                    }
                }


                else {
                    et2Edit.setText(sp1Edit.getSelectedItem().toString());
                    et2Edit.setEnabled(false);
                }
            }


            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });


        sp2Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp2Edit.getSelectedItem().toString().equals("other")) {
                    et3Edit.setEnabled(true);

                }
                else {
                    et3Edit.setText(sp2Edit.getSelectedItem().toString());
                    et3Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sp3Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp3Edit.getSelectedItem().toString().equals("other")) {
                    et4Edit.setEnabled(true);

                }

                else {
                    et4Edit.setText(sp3Edit.getSelectedItem().toString());
                    et4Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sp4Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp4Edit.getSelectedItem().toString().equals("other")) {

                    et5Edit.setEnabled(true);

                }
                else {
                    et5Edit.setText(sp4Edit.getSelectedItem().toString());
                    et5Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sp5Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp5Edit.getSelectedItem().toString().equals("other")) {
                    et6Edit.setEnabled(true);

                }
                else {
                    et6Edit.setText(sp5Edit.getSelectedItem().toString());
                    et6Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        sp6Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp6Edit.getSelectedItem().toString().equals("other")) {
                    et7Edit.setEnabled(true);

                }
                else
                {
                    et7Edit.setText(sp6Edit.getSelectedItem().toString());
                    et7Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sp7Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp7Edit.getSelectedItem().toString().equals("other")) {
                    et8Edit.setEnabled(true);
                }

                else {
                    et8Edit.setText(sp7Edit.getSelectedItem().toString());
                    et8Edit.setEnabled(false);
                }
            }


            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        sp8Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp8Edit.getSelectedItem().toString().equals("other")) {
                    et9Edit.setEnabled(true);

                }
                else
                {
                    et9Edit.setText(sp8Edit.getSelectedItem().toString());
                    et9Edit.setEnabled(false);
                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sp9Edit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {

                if (sp9Edit.getSelectedItem().toString().equals("other")) {
                    et10Edit.setEnabled(true);

                }
                else {
                    et10Edit.setText(sp9Edit.getSelectedItem().toString());
                    et10Edit.setEnabled(false);

                }
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });


    }



    private class LoadImage extends AsyncTask<String, String, Bitmap> {

        private recipe w1;
        private MainActivity m1;
        private recipeImageUpload riu1;
        private newdish n2;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(EditScreen.this);
            pDialog.setMessage("Loading Image ....");
            pDialog.show();

        }
        protected Bitmap doInBackground(String... args) {
            try {
                bitmap = BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());

            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        protected void onPostExecute(Bitmap image) {

            if (image != null) {

                recipeImage1.setMaxHeight(0);
                recipeImage1.setMaxWidth(1);

                // if (m1.up == 0)

                // {
                //    if (m1.up == 0) {
                if (n.imageArray.size() == 0) {
                    n.imageArray.add(image);
                    recipeImage1.setImageBitmap(image);
                } else {
                    n.imageArray.set(wEdit.select, image);
                    recipeImage1.setImageBitmap(n.imageArray.get(wEdit.select));
                }
                // }

                // } else {

                //     n.imageArray.set(n.imageArray.size() - 1, image);
                // recipeImage1.setImageBitmap(image);
                //}


                pDialog.dismiss();
            }



            else
            {
                pDialog.dismiss();
                Toast.makeText(EditScreen.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();




            }
        }
    }




}











