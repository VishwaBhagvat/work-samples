package com.example.myfragments.myfragments;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class mondayBreakfast extends AppCompatActivity {

    public static int select5;
    public static String itemName;
    private mealScreen1 m1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monday_breakfast);


        final ListView listView = (ListView) findViewById(R.id.mondaybreakfastlist);




        // Create a List from String Array elements


        // Create an ArrayAdapter from List
         final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, m1.MondaybreakfastMeals) {


            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);




                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 500;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);
        if (listView.getCount() == 0) {
            Intent intent = new Intent(mondayBreakfast.this, eatingOut.class);
            startActivity(intent);

        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {


                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);

                select5 = listView.getSelectedItemPosition();
                itemName = listView.getItemAtPosition(pos).toString();
                arrayAdapter.remove(itemName);
                arrayAdapter.notifyDataSetChanged();
                if (arrayAdapter.getCount() == 0) {
                    Intent intent = new Intent(mondayBreakfast.this, eatingOut.class);
                    startActivity(intent);
                }


            }
        });

    }
        }












