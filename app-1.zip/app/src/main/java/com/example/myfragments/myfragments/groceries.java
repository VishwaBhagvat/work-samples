package com.example.myfragments.myfragments;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class groceries extends Activity {

    public static int select5;
    public static String itemName;
    private newdish nh;
    private mealScreen1 m1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groceries);


        final ListView listView = (ListView) findViewById(R.id.groceriesItems);




        // Create a List from String Array elements


        // Create an ArrayAdapter from List
        final ArrayList<Map<String, Integer>> list = new ArrayList<Map<String, Integer>>();
        Map<String, Integer> map;
        int count=nh.cookItemsNoDuplicates.size();
        for(int i=0; i<count; i++)
        {
            map=new HashMap<String, Integer>();
            map.put(nh.cookItemsNoDuplicates.get(i), nh.countItem.get(i));
            list.add(map);
        }

        final ArrayAdapter<Map<String, Integer>> arrayAdapter = new ArrayAdapter<Map<String, Integer>>
                (this, android.R.layout.simple_list_item_1, list)

        {


            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);




                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 500;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {





            }
        });

    }
}









