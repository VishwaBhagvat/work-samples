package com.example.myfragments.myfragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;




/**
 * A simple {@link Fragment} subclass.
 */
public class PortraitFragment extends android.app.Fragment {

    private recipe r15;


    public PortraitFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_portrait, container, false);

        final ListView listView = (ListView) view.findViewById(R.id.lv);
        // Create a List from String Array elements


        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_list_item_1, r15.recipes) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);

                // Get the Layout Parameters for ListView Current Item View
                ViewGroup.LayoutParams params = view.getLayoutParams();

                // Set the height of the Item View

                params.width = 500;
                view.setLayoutParams(params);
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };


        listView.setAdapter(arrayAdapter);


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {

                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);
                r15.str = listView.getItemAtPosition(pos).toString().toLowerCase();

                r15.select = pos;//listView.getSelectedItemPosition();
                // recipes.remove(select);
                // e.recipeTextEdit.setText(str);

                //  Intent intent = new Intent(recipe.this, EditScreen.class);
                startActivity(new Intent(getActivity(), EditScreen.class));

                //  j=listView.getSelectedItem().toString();
                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {

                // n.numbers.remove(pos);
                // n.cookItems.remove(pos);
                r15.str = listView.getItemAtPosition(pos).toString().toLowerCase();

                r15.select = pos;//listView.getSelectedItemPosition();



                // recipes.remove(select);
                // e.recipeTextEdit.setText(str);

                //  Intent intent = new Intent(recipe.this, EditScreen.class);
                startActivity(new Intent(getActivity(), mealScreen1.class));

                //  j=listView.getSelectedItem().toString();

            }
        });



        return view;
    }

}








// Inflate the layout for this fragment
