package com.example.myfragments.myfragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;

//import com.example.vishwa.whatsfordinner;

public class MainActivity extends Activity {
    private newdish n;
    public static int up;
    private recipeImageUpload mr;
    //int orientation = getResources().getConfiguration().orientation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton A = (ImageButton) findViewById(R.id.dish);
        ImageButton B = (ImageButton) findViewById(R.id.recipe);
        ImageButton Banner = (ImageButton) findViewById(R.id.ic_launcher);
        ImageButton meal = (ImageButton) findViewById(R.id.meals);
        ImageButton groceriesButton = (ImageButton) findViewById(R.id.groceries);
        Banner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Banner.class);
                startActivity(intent);
            }
        });

        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                up = 0;
                mr.noAdd = 0;
                Intent intent = new Intent(MainActivity.this, newdish.class);
                startActivity(intent);
            }
        });

        meal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, mainMealScreen.class);
                startActivity(intent);

            }
        });
        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, recipe.class);
                startActivity(intent);

            }
        });
        groceriesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, groceries.class);
                startActivity(intent);

            }
        });

    }
}





      /*  ImageView ic_launcher=(ImageView)findViewById(R.id.ic_launcher);
        ic_launcher.setScaleType(ImageView.ScaleType.FIT_XY);
        TextView t2=(TextView) findViewById(R.id.meals);
        t2.setMovementMethod(LinkMovementMethod.getInstance());
        */

